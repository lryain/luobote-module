#!/bin/sh
/opt/AVRcamVIEW/jre/bin/java -jar /opt/AVRcamVIEW/lib/AVRcamVIEW.jar
